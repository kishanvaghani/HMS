The Slider Revolution plugin is used for the main sliders (in banner section) of the template.

Slider revolution plugin has its own license. It is not permitted to extract and use the
slider-revolution plugin outside of the template.

In order to use the plugin on a stand-alone basis you should buy your own license
from https://codecanyon.net/item/slider-revolution-responsive-jquery-plugin/2580848